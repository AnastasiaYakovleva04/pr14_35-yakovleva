﻿namespace pr14_35_yakovleva
{
    partial class pr14_35
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.InputN = new System.Windows.Forms.NumericUpDown();
            this.n = new System.Windows.Forms.Label();
            this.Perform = new System.Windows.Forms.Button();
            this.Result = new System.Windows.Forms.ListBox();
            this.z3 = new System.Windows.Forms.Label();
            this.z4 = new System.Windows.Forms.Label();
            this.InputPath = new System.Windows.Forms.TextBox();
            this.Path = new System.Windows.Forms.Label();
            this.CheckFile = new System.Windows.Forms.Button();
            this.FileContent = new System.Windows.Forms.ListBox();
            this.FioPath = new System.Windows.Forms.Label();
            this.z5 = new System.Windows.Forms.Label();
            this.InputFioPath = new System.Windows.Forms.TextBox();
            this.AwPath = new System.Windows.Forms.Label();
            this.InputAw = new System.Windows.Forms.TextBox();
            this.FilesContent = new System.Windows.Forms.ListBox();
            this.OpenFiles = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.InputN)).BeginInit();
            this.SuspendLayout();
            // 
            // InputN
            // 
            this.InputN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputN.Location = new System.Drawing.Point(31, 102);
            this.InputN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.InputN.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.InputN.Name = "InputN";
            this.InputN.Size = new System.Drawing.Size(205, 30);
            this.InputN.TabIndex = 0;
            this.InputN.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // n
            // 
            this.n.AutoSize = true;
            this.n.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.n.Location = new System.Drawing.Point(26, 74);
            this.n.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.n.Name = "n";
            this.n.Size = new System.Drawing.Size(107, 25);
            this.n.TabIndex = 1;
            this.n.Text = "Введите n";
            // 
            // Perform
            // 
            this.Perform.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Perform.Location = new System.Drawing.Point(31, 141);
            this.Perform.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Perform.Name = "Perform";
            this.Perform.Size = new System.Drawing.Size(205, 39);
            this.Perform.TabIndex = 2;
            this.Perform.Text = "Выпонить";
            this.Perform.UseVisualStyleBackColor = true;
            this.Perform.Click += new System.EventHandler(this.Perform_Click);
            // 
            // Result
            // 
            this.Result.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Result.FormattingEnabled = true;
            this.Result.ItemHeight = 25;
            this.Result.Location = new System.Drawing.Point(31, 205);
            this.Result.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(204, 229);
            this.Result.TabIndex = 3;
            // 
            // z3
            // 
            this.z3.AutoSize = true;
            this.z3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z3.Location = new System.Drawing.Point(26, 39);
            this.z3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.z3.Name = "z3";
            this.z3.Size = new System.Drawing.Size(24, 25);
            this.z3.TabIndex = 4;
            this.z3.Text = "3";
            // 
            // z4
            // 
            this.z4.AutoSize = true;
            this.z4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z4.Location = new System.Drawing.Point(258, 39);
            this.z4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.z4.Name = "z4";
            this.z4.Size = new System.Drawing.Size(24, 25);
            this.z4.TabIndex = 5;
            this.z4.Text = "4";
            // 
            // InputPath
            // 
            this.InputPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputPath.Location = new System.Drawing.Point(264, 102);
            this.InputPath.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.InputPath.Name = "InputPath";
            this.InputPath.Size = new System.Drawing.Size(280, 30);
            this.InputPath.TabIndex = 6;
            // 
            // Path
            // 
            this.Path.AutoSize = true;
            this.Path.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Path.Location = new System.Drawing.Point(258, 74);
            this.Path.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Path.Name = "Path";
            this.Path.Size = new System.Drawing.Size(219, 25);
            this.Path.TabIndex = 7;
            this.Path.Text = "Введите путь к файлу";
            // 
            // CheckFile
            // 
            this.CheckFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CheckFile.Location = new System.Drawing.Point(264, 141);
            this.CheckFile.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CheckFile.Name = "CheckFile";
            this.CheckFile.Size = new System.Drawing.Size(281, 39);
            this.CheckFile.TabIndex = 8;
            this.CheckFile.Text = "Открыть файл";
            this.CheckFile.UseVisualStyleBackColor = true;
            this.CheckFile.Click += new System.EventHandler(this.CheckFile_Click);
            // 
            // FileContent
            // 
            this.FileContent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FileContent.FormattingEnabled = true;
            this.FileContent.ItemHeight = 25;
            this.FileContent.Location = new System.Drawing.Point(264, 205);
            this.FileContent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FileContent.Name = "FileContent";
            this.FileContent.Size = new System.Drawing.Size(433, 229);
            this.FileContent.TabIndex = 9;
            // 
            // FioPath
            // 
            this.FioPath.AutoSize = true;
            this.FioPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FioPath.Location = new System.Drawing.Point(709, 74);
            this.FioPath.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.FioPath.Name = "FioPath";
            this.FioPath.Size = new System.Drawing.Size(280, 25);
            this.FioPath.TabIndex = 10;
            this.FioPath.Text = "Введите путь к файлу с фио";
            // 
            // z5
            // 
            this.z5.AutoSize = true;
            this.z5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z5.Location = new System.Drawing.Point(709, 39);
            this.z5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.z5.Name = "z5";
            this.z5.Size = new System.Drawing.Size(24, 25);
            this.z5.TabIndex = 11;
            this.z5.Text = "5";
            // 
            // InputFioPath
            // 
            this.InputFioPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputFioPath.Location = new System.Drawing.Point(709, 103);
            this.InputFioPath.Margin = new System.Windows.Forms.Padding(4);
            this.InputFioPath.Name = "InputFioPath";
            this.InputFioPath.Size = new System.Drawing.Size(280, 30);
            this.InputFioPath.TabIndex = 12;
            // 
            // AwPath
            // 
            this.AwPath.AutoSize = true;
            this.AwPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AwPath.Location = new System.Drawing.Point(704, 137);
            this.AwPath.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.AwPath.Name = "AwPath";
            this.AwPath.Size = new System.Drawing.Size(427, 25);
            this.AwPath.TabIndex = 13;
            this.AwPath.Text = "Введите путь к файлу с  возрастом и весом";
            // 
            // InputAw
            // 
            this.InputAw.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputAw.Location = new System.Drawing.Point(709, 166);
            this.InputAw.Margin = new System.Windows.Forms.Padding(4);
            this.InputAw.Name = "InputAw";
            this.InputAw.Size = new System.Drawing.Size(280, 30);
            this.InputAw.TabIndex = 14;
            // 
            // FilesContent
            // 
            this.FilesContent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FilesContent.FormattingEnabled = true;
            this.FilesContent.ItemHeight = 25;
            this.FilesContent.Location = new System.Drawing.Point(709, 251);
            this.FilesContent.Margin = new System.Windows.Forms.Padding(4);
            this.FilesContent.Name = "FilesContent";
            this.FilesContent.Size = new System.Drawing.Size(433, 229);
            this.FilesContent.TabIndex = 15;
            // 
            // OpenFiles
            // 
            this.OpenFiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.OpenFiles.Location = new System.Drawing.Point(709, 205);
            this.OpenFiles.Margin = new System.Windows.Forms.Padding(4);
            this.OpenFiles.Name = "OpenFiles";
            this.OpenFiles.Size = new System.Drawing.Size(281, 39);
            this.OpenFiles.TabIndex = 16;
            this.OpenFiles.Text = "Открыть файлы";
            this.OpenFiles.UseVisualStyleBackColor = true;
            this.OpenFiles.Click += new System.EventHandler(this.OpenFiles_Click);
            // 
            // pr14_35
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1254, 554);
            this.Controls.Add(this.OpenFiles);
            this.Controls.Add(this.FilesContent);
            this.Controls.Add(this.InputAw);
            this.Controls.Add(this.AwPath);
            this.Controls.Add(this.InputFioPath);
            this.Controls.Add(this.z5);
            this.Controls.Add(this.FioPath);
            this.Controls.Add(this.FileContent);
            this.Controls.Add(this.CheckFile);
            this.Controls.Add(this.Path);
            this.Controls.Add(this.InputPath);
            this.Controls.Add(this.z4);
            this.Controls.Add(this.z3);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.Perform);
            this.Controls.Add(this.n);
            this.Controls.Add(this.InputN);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "pr14_35";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.InputN)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown InputN;
        private System.Windows.Forms.Label n;
        private System.Windows.Forms.Button Perform;
        private System.Windows.Forms.ListBox Result;
        private System.Windows.Forms.Label z3;
        private System.Windows.Forms.Label z4;
        private System.Windows.Forms.TextBox InputPath;
        private System.Windows.Forms.Label Path;
        private System.Windows.Forms.Button CheckFile;
        private System.Windows.Forms.ListBox FileContent;
        private System.Windows.Forms.Label FioPath;
        private System.Windows.Forms.Label z5;
        private System.Windows.Forms.TextBox InputFioPath;
        private System.Windows.Forms.Label AwPath;
        private System.Windows.Forms.TextBox InputAw;
        private System.Windows.Forms.ListBox FilesContent;
        private System.Windows.Forms.Button OpenFiles;
    }
}

