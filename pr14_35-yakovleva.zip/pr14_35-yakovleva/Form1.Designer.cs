﻿namespace pr14_35_yakovleva
{
    partial class pr14_35
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.InputN = new System.Windows.Forms.NumericUpDown();
            this.n = new System.Windows.Forms.Label();
            this.Perform = new System.Windows.Forms.Button();
            this.Result = new System.Windows.Forms.ListBox();
            this.z3 = new System.Windows.Forms.Label();
            this.z4 = new System.Windows.Forms.Label();
            this.InputPath = new System.Windows.Forms.TextBox();
            this.Path = new System.Windows.Forms.Label();
            this.CheckFile = new System.Windows.Forms.Button();
            this.FileContent = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.InputN)).BeginInit();
            this.SuspendLayout();
            // 
            // InputN
            // 
            this.InputN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputN.Location = new System.Drawing.Point(99, 87);
            this.InputN.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.InputN.Name = "InputN";
            this.InputN.Size = new System.Drawing.Size(154, 26);
            this.InputN.TabIndex = 0;
            this.InputN.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // n
            // 
            this.n.AutoSize = true;
            this.n.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.n.Location = new System.Drawing.Point(95, 64);
            this.n.Name = "n";
            this.n.Size = new System.Drawing.Size(89, 20);
            this.n.TabIndex = 1;
            this.n.Text = "Введите n";
            // 
            // Perform
            // 
            this.Perform.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Perform.Location = new System.Drawing.Point(99, 119);
            this.Perform.Name = "Perform";
            this.Perform.Size = new System.Drawing.Size(154, 32);
            this.Perform.TabIndex = 2;
            this.Perform.Text = "Выпонить";
            this.Perform.UseVisualStyleBackColor = true;
            this.Perform.Click += new System.EventHandler(this.Perform_Click);
            // 
            // Result
            // 
            this.Result.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Result.FormattingEnabled = true;
            this.Result.ItemHeight = 20;
            this.Result.Location = new System.Drawing.Point(99, 171);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(154, 204);
            this.Result.TabIndex = 3;
            // 
            // z3
            // 
            this.z3.AutoSize = true;
            this.z3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z3.Location = new System.Drawing.Point(43, 36);
            this.z3.Name = "z3";
            this.z3.Size = new System.Drawing.Size(19, 20);
            this.z3.TabIndex = 4;
            this.z3.Text = "3";
            // 
            // z4
            // 
            this.z4.AutoSize = true;
            this.z4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z4.Location = new System.Drawing.Point(280, 36);
            this.z4.Name = "z4";
            this.z4.Size = new System.Drawing.Size(19, 20);
            this.z4.TabIndex = 5;
            this.z4.Text = "4";
            // 
            // InputPath
            // 
            this.InputPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputPath.Location = new System.Drawing.Point(284, 87);
            this.InputPath.Name = "InputPath";
            this.InputPath.Size = new System.Drawing.Size(211, 26);
            this.InputPath.TabIndex = 6;
            // 
            // Path
            // 
            this.Path.AutoSize = true;
            this.Path.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Path.Location = new System.Drawing.Point(280, 64);
            this.Path.Name = "Path";
            this.Path.Size = new System.Drawing.Size(180, 20);
            this.Path.TabIndex = 7;
            this.Path.Text = "Введите путь к файлу";
            // 
            // CheckFile
            // 
            this.CheckFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CheckFile.Location = new System.Drawing.Point(284, 119);
            this.CheckFile.Name = "CheckFile";
            this.CheckFile.Size = new System.Drawing.Size(211, 32);
            this.CheckFile.TabIndex = 8;
            this.CheckFile.Text = "Открыть файл";
            this.CheckFile.UseVisualStyleBackColor = true;
            this.CheckFile.Click += new System.EventHandler(this.CheckFile_Click);
            // 
            // FileContent
            // 
            this.FileContent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FileContent.FormattingEnabled = true;
            this.FileContent.ItemHeight = 20;
            this.FileContent.Location = new System.Drawing.Point(284, 171);
            this.FileContent.Name = "FileContent";
            this.FileContent.Size = new System.Drawing.Size(211, 204);
            this.FileContent.TabIndex = 9;
            // 
            // pr14_35
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.FileContent);
            this.Controls.Add(this.CheckFile);
            this.Controls.Add(this.Path);
            this.Controls.Add(this.InputPath);
            this.Controls.Add(this.z4);
            this.Controls.Add(this.z3);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.Perform);
            this.Controls.Add(this.n);
            this.Controls.Add(this.InputN);
            this.Name = "pr14_35";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.InputN)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown InputN;
        private System.Windows.Forms.Label n;
        private System.Windows.Forms.Button Perform;
        private System.Windows.Forms.ListBox Result;
        private System.Windows.Forms.Label z3;
        private System.Windows.Forms.Label z4;
        private System.Windows.Forms.TextBox InputPath;
        private System.Windows.Forms.Label Path;
        private System.Windows.Forms.Button CheckFile;
        private System.Windows.Forms.ListBox FileContent;
    }
}

