﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace pr14_35_yakovleva
{
    public partial class pr14_35 : Form
    {
        public pr14_35()
        {
            InitializeComponent();
        }

        private void Perform_Click(object sender, EventArgs e)
        {
            int n = (int)InputN.Value;
            Queue<int> q = new Queue<int>();
            for (int i = 1; i <= n; i++)
                q.Enqueue(i);
            Result.Items.Clear();
            while (q.Count > 0)
                Result.Items.Add(q.Dequeue().ToString());
        }

        private void CheckFile_Click(object sender, EventArgs e)
        {
            string path = InputPath.Text;
            if (File.Exists(path))
            {
                using (StreamReader sr = File.OpenText(path))
                {

                }
            }
            else
                MessageBox.Show("Файла с таким именем не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
