﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace pr14_35_yakovleva
{
    public partial class pr14_35 : Form
    {
        public pr14_35()
        {
            InitializeComponent();
        }

        private void Perform_Click(object sender, EventArgs e)
        {
            int n = (int)InputN.Value;
            Queue<int> q = new Queue<int>();
            for (int i = 1; i <= n; i++)
                q.Enqueue(i);
            Result.Items.Clear();
            while (q.Count > 0)
                Result.Items.Add(q.Dequeue().ToString());
        }

        private void CheckFile_Click(object sender, EventArgs e)
        {
            string path = InputPath.Text;
            if (File.Exists(path))
            {
                Queue<Person> people = new Queue<Person>();
                using (StreamReader sr = File.OpenText(path))
                {
                    string line;
                    while (!(sr.EndOfStream))
                    {
                        line = sr.ReadLine();
                        string[] parts = line.Split(' ');
                        if (parts.Length == 5)
                        {
                            try
                            {
                                Person p = new Person
                                {
                                    surname = parts[0],
                                    name = parts[1],
                                    patronimic = parts[2],
                                    age = int.Parse(parts[3]),
                                    weight = int.Parse(parts[4])
                                };
                                people.Enqueue(p);
                            }
                            catch (FormatException)
                            {
                                MessageBox.Show("В файле ошибка в формате данных", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                            MessageBox.Show("В файле неверная запись", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                Queue<Person> younger40 = new Queue<Person>();
                Queue<Person> older40 = new Queue<Person>();
                while (people.Count > 0)
                {
                    Person p = people.Dequeue();
                    if (p.age < 40)
                        younger40.Enqueue(p);
                    else
                        older40.Enqueue(p);
                }
                FileContent.Items.Clear();
                FileContent.Items.Add("Люди младше 40 лет:\r\n");
                foreach (Person p in younger40)
                    FileContent.Items.Add(p.Info() + "\r\n");
                FileContent.Items.Add("Остальные:\r\n");
                foreach (Person p in older40)
                    FileContent.Items.Add(p.Info() + "\r\n");


            }
            else
                MessageBox.Show("Файла с таким именем не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void OpenFiles_Click(object sender, EventArgs e)
        {
            string path_fio = InputFioPath.Text;
            string path_aw = InputAw.Text;
            if (File.Exists(path_aw) && File.Exists(path_fio))
            {
                Queue<Person> people = new Queue<Person>();
                using (StreamReader sr = File.OpenText(path_fio))
                {
                    using (StreamReader sr_aw = File.OpenText(path_aw))
                    {
                        string names;
                        string aws;
                        while (!(sr.EndOfStream))
                        {
                            names = sr.ReadLine();
                            string[] names_parts = names.Split(' ');
                            aws = sr_aw.ReadLine();
                            string[] aws_parts = aws.Split(' ');
                            if (names_parts.Length == 3 && aws_parts.Length == 2)
                            {
                                try
                                {
                                    Person p = new Person
                                    {
                                        surname = names_parts[0],
                                        name = names_parts[1],
                                        patronimic = names_parts[2],
                                        age = int.Parse(aws_parts[0]),
                                        weight = int.Parse(aws_parts[1])
                                    };
                                    people.Enqueue(p);
                                }
                                catch (FormatException)
                                {
                                    MessageBox.Show("В файле ошибка в формате данных", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            else
                                MessageBox.Show("В файле неверная запись", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                var groupped = people
                    .OrderBy(p => p.age)
                    .GroupBy(p => p.surname
                    .FirstOrDefault())
                    .SelectMany(group => new[] { $"Группа: {group.Key}" }
                    .Concat(group.Select(p => p.Info())));
                FilesContent.Items.Clear();
                foreach (var item in groupped)
                    FilesContent.Items.Add(item);
            }
            else
                MessageBox.Show("Файла с таким именем не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
