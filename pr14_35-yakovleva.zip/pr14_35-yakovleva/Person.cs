﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr14_35_yakovleva
{
    public class Person
    {
        public string surname { get; set; }
        public string name { get; set; }
        public string patronimic { get; set; }
        public int age { get; set; }
        public int weight { get; set; }

        public string Info()
        {
            return $"{surname} {name} {patronimic} {age} {weight}";
        }
    }
}
